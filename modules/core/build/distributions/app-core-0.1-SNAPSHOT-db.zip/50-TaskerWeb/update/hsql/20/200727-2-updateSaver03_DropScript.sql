alter table TASKERWEB_SAVER drop column DATA___U81031 cascade ;
alter table TASKERWEB_SAVER drop column ANSWER__U77458 cascade ;
