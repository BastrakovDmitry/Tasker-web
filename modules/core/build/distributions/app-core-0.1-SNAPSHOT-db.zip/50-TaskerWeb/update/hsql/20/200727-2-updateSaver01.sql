alter table TASKERWEB_SAVER alter column ANSWER rename to ANSWER__U61437 ^
