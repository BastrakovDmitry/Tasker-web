alter table TASKERWEB_SOME_DATA drop column VERSION__U94443 cascade ;
alter table TASKERWEB_SOME_DATA drop column CREATE_TS__U08069 cascade ;
alter table TASKERWEB_SOME_DATA drop column CREATED_BY__U07288 cascade ;
alter table TASKERWEB_SOME_DATA drop column UPDATE_TS__U54794 cascade ;
alter table TASKERWEB_SOME_DATA drop column UPDATED_BY__U12896 cascade ;
alter table TASKERWEB_SOME_DATA drop column DELETE_TS__U03684 cascade ;
alter table TASKERWEB_SOME_DATA drop column DELETED_BY__U72664 cascade ;
