alter table TASKERWEB_SAVER alter column ANSWER rename to ANSWER__U77458 ^
alter table TASKERWEB_SAVER alter column DATA_ rename to DATA___U81031 ^
alter table TASKERWEB_SAVER alter column DATA___U81031 set null ;
