alter table TASKERWEB_SOME_DATA alter column TASK_ set data type varchar(255) ;
